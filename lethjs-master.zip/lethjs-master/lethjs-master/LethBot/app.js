//Discord consts
const discord = require("discord.js");
const client = new discord.Client();
const token = 'MzE5OTI4NTQwNjg0MzUzNTM2.DkRczg.UJb21lvopLfqlatm_74P-g1P3bU';
//Additional package consts
//File-system
const fs = require("fs");
//Money conversion
const fx = require("money");
let points = JSON.parse(fs.readFileSync("./points.json", "utf8"));

//Set '!' prefix to all commands
function commandIs(str, message) {
	return message.content.toLowerCase().startsWith("!" + str); //check if message starts with '!'
}
//add new commands here
commandList = ["hello", "commands", "serverInfo", "emojis", "channels, mylevel"];

//---------------------------------------------------------------------------------------------
//Write to console when bot is ready
client.on('ready', () => {
	console.log(`Logged in as ${client.user.username}!`);
	//const collection = client.users.clone();
});
//---------------------------------------------------------------------------------------------
//On message event
client.on('message', message => {
	var args = message.content.split(" ");
	//Points commands
	if (message.author.bot) return; // always ignore bots!

	// if the points don"t exist, init to 0;
	if (!points[message.author.id]) points[message.author.id] = {
		points: 0,
		level: 0
	};
	points[message.author.id].points++;


	if (commandIs("currency", message) && (message.author != client.user)) {
		console.log(args[1] + " " + args[2] + " " + args[3] + " ");
		var amount = args[1];
		var fromCur = args[2];
		var toCur = args[3];
		message.channel.send(fx(amount).from(fromCur).to(toCur)).toString();
	}

	// And then, we save the edited file.
	fs.writeFile("./points.json", JSON.stringify(points), (err) => {
		if (err) console.error(err)
	});
	if (commandIs("mylevel", message) && (message.author != client.user)) { //must have prefix and author not be bot
		console.log("level command initiated");
		let userPoints = points[message.author.id] ? points[message.author.id].points : 0;
		let curLevel = Math.floor(0.1 * Math.sqrt(userPoints));
		message.channel.send(`You are currently level ${curLevel}, with ${userPoints} points.`);
	}
	//----------------------------------------------
	//Message specific commands
	if (commandIs("hello", message) && (message.author != client.user)) { //must have prefix and author not be bot
		console.log("'hello' command initiated");
		message.channel.send("Hello " + message.author.username);
	}
	if (commandIs("linkAvatar", message) && (message.author != client.user)) { //must have prefix and author not be bot
		console.log("'linkAvatar");
		message.channel.send("" + collection[3].username);
	}
	//display commands as list
	if (commandIs("commands", message) && (message.author != client.user)) {
		console.log("commands command initiated");
		commandListString = "These are the available commands:\n----------------------------------";
		commandList.forEach(element => {
			commandListString += "- " + element + "\n";
		});
		message.channel.send(commandListString);
	}
	//show server information
	if (commandIs("serverInfo", message) && (message.author != client.user)) {
		console.log("serverInfo command initiated");
		message.channel.send("This server's name is " + message.guild + "\nTotal members: " +
			message.guild.memberCount);
	}
	//get custom emojis information
	if (commandIs("emojis", message) && (message.author != client.user)) {
		console.log("emojis command initiated");
		emojiArray = client.emojis.array();
		emojiString = "";
		emojiArray.forEach(element => {
			emojiString += element.name + "\n";
		});
		message.channel.send(emojiString);
	}
	//get channels information
	if (commandIs("channels", message) && (message.author != client.user)) {
		console.log("channels command initiated")
		channelsListArray = message.guild.channels.array();
		channelsString = "";
		channelsListArray.forEach(element => {
			if (element.type != "category") {
				channelsString += "\n-------------------------------\nName: " + element.name + "\nCreated At: " +
					element.createdAt.toDateString() + "\nType: " + element.type;
			}
		});
		channelsString += "\n-------------------------------";
		message.channel.send(channelsString);
	}
	//----------------------------------------------
	//Event based messages
});
//---------------------------------------------------------------------------------------------
//Show name of the custom emoji when it is created
client.on('emojiCreate', emoji => {
	generalChannel = emoji.guild.channels.find(channel => channel.name === 'general');
	generalChannel.send(emoji.name + " was created")
});

//Login token
client.login(token);

